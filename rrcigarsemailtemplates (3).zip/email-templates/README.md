# R&R Cigars — Email Templates

Two ready-to-use templates, both built from the real logo artwork and the confirmed
business address (5946 Osgood Ave N, Oak Park Heights, MN 55082).

## 1. `signature.html` — Gmail signature

A one-time-setup signature block with the logo, name/title line, address, and email, in
R&R's red/gold branding — currently set for Bret (Red) Fraser, Owner, at
red@r-rcigars.com. No phone number is on it yet since that's still pending. The logo is
embedded directly in the file (as a data URI) purely so the file previews correctly on
its own — see the note below on why that same embedding doesn't survive into Gmail.

**Install (two parts — text, then image):**
1. Open `signature.html` in a browser (double-click it).
2. Click inside the signature, press Ctrl/Cmd+A to select all, then Ctrl/Cmd+C to copy.
3. Gmail → Settings (gear) → "See all settings" → General → Signature → "Create new" →
   click into the empty box → Ctrl/Cmd+V to paste → scroll down → Save Changes.
4. Gmail will drop the logo image on paste (see below) and may leave behind a stray link
   or blank line where it was — click that and delete it.
5. Click into the signature box where the logo should sit, then click the small image
   icon in the signature editor's toolbar (next to the link/formatting icons).
6. Choose "Upload," pick `images/rr-logo-email.png` from this folder, and insert it.
7. Drag the resize handle on the inserted image down to about 120px wide so it matches
   the text size, then Save Changes.
8. For a different person, swap the "Bret (Red) Fraser" name/title line and the email
   address before pasting.
9. Once the store phone number is set (expected Tuesday), add a line back in under the
   address for it — happy to do that update when you have the number.

**Why the logo shows up as just a URL:** Gmail's signature editor strips embedded
(data-URI) images out of anything pasted in from outside Gmail, as a security measure —
it doesn't render the picture, and can leave the raw image address behind as plain text
instead. That's expected, not a broken file. Gmail's own "Upload" button (step 5–7) is
the one path that actually keeps an image in a signature, since Gmail hosts that copy
itself. The text, colors, and links paste in fine — it's only the image that needs the
separate upload step.

Repeat per Gmail account. Outlook and Apple Mail have their own signature editors and
image-insert buttons, but the same principle applies — use each client's own image
upload rather than pasting the logo in.

## 2. `email-template.html` — Announcement / newsletter template

A full HTML email layout (header with logo → headline → body copy → button → footer
with store info) for one-off sends: new arrivals, events, promotions, seasonal updates —
this is the same shape Red's transition-pricing announcement would use going forward.

Built with an HTML-table layout (not CSS grid/flexbox) because that's still what
renders reliably across Outlook, Gmail, and Apple Mail — email clients lag years behind
browsers on CSS support.

**Placeholders to fill in per send** (all in brackets):
- `[Announcement headline goes here]`
- The body paragraph under "Hi [First Name],"
- `[Button text, e.g. Visit Us]` and its link target
- `{{unsubscribe_link}}` — see note below

The footer currently shows only the address and `sales@r-rcigars.com` — no phone number
yet, same reason as the signature. Add it back into the footer once it's confirmed.

**Before sending any real campaign:**
- This template references the logo at `https://preview.r-rcigars.com/images/rr-logo-email.png`.
  `images/rr-logo-email.png` is included in this folder — upload it into the `images/`
  folder of the preview GitHub repo (same web-upload method used for the other site
  files) so that URL resolves. Once r-rcigars.com is live on Bluehost, switch the `src`
  to `https://r-rcigars.com/images/rr-logo-email.png` instead.
- Email templates aren't pasted into Gmail like the signature — they're meant to be
  loaded into a sending tool (Mailchimp, Constant Contact, Formspree partner tools, or
  Gmail's "Insert HTML" via a browser extension). Plain Gmail compose doesn't accept
  raw HTML paste the way its signature box does.
- The footer's physical address and an unsubscribe link are a CAN-SPAM requirement for
  any commercial/promotional email in the US — keep both on every send. The
  `{{unsubscribe_link}}` placeholder is written in the merge-tag style most sending
  platforms use; replace it with whatever your platform's actual unsubscribe tag or URL
  is.

## Logo asset

`images/rr-logo-email.png` — the R&R Cigars wordmark, trimmed and exported with a
transparent background at 640×341px, sourced from the vector logo
(`R & R and Reds Lounge/Artifacts/R & R1.svg`) already in the project files. This is a
different, higher-resolution export than any logo currently on the live site pages, so
if you want it there too (e.g. as a favicon or header mark) just say so.
